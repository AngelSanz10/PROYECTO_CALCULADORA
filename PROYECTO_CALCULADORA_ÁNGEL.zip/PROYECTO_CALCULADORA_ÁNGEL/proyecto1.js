// Array para almacenar el historial de operaciones
let historial = [];
let operador;

// Función que muestra todos los resultados del historial
function mostrarHistorial() {
  try {
    // Recorrer todo el historial
    console.log("HISTORIAL");
    for (let i = 0; i < historial.length; i++) {
      console.log(historial[i]);
    }
  } catch (error) {
    console.error("Fallo al mostrar el historial:", error.message);
  }
}

// Función que realiza las operaciones
function operacion(tipo, num1, num2) {
  let resultado = null;

  switch (tipo) {
    case "1": // Suma
      operador = "+";
      resultado = num1 + num2;
      break;
    case "2": // Resta
      operador = "-";
      resultado = num1 - num2;
      break;
    case "3": // Multiplicación
      operador = "*";
      resultado = num1 * num2;
      break;
    case "4": // División
      operador = "/";
      let divisionCorrecta = false;  // Variable para controlar si la división es correcta

    while (!divisionCorrecta) {
      try {
        if (num2 === 0) {
          throw new Error("No se puede dividir por cero.");  // Lanzamos un error si el divisor es cero
        }

        resultado = num1 / num2;  // Realizamos la división

        // Comprobamos si el resultado es negativo
        if (resultado < 0) {
          throw new Error("La división ha dado un resultado negativo.");  // Lanzamos un error si el resultado es negativo
        }

        // Si no se lanza ninguna excepción, la división es válida
        divisionCorrecta = true;

      } catch (error) {
        // Si se captura un error, mostramos el mensaje y pedimos nuevos números
        alert(error.message);
        num1 = validarInput("Ingresa el primer número para la división:");
        num2 = validarInput("Ingresa el segundo número para la división:");
      }
  }

  break;

    case "5": // Raíz cuadrada
      if (num1 < 0) {
        alert("Error: No se puede calcular la raíz cuadrada de un número negativo.");
        return null;
      }
      operador = "√";
      resultado = Math.sqrt(num1);
      break;
    default:
      alert("Opción no válida. Por favor selecciona una operación válida.");
      return null;
  }

  return resultado;
}

// Función principal que controla el flujo de la calculadora
function calculadora() {
  try {
    // Pedir el primer número al usuario
    const num1 = validarInput("Ingresa el primer número:");
    let num2; // Declaramos num2, que solo pediremos si la operación lo requiere

    let tipo;
    // Pedir la operación a realizar y asegurarnos de que sea un número del 1 al 5
    while (true) {
      tipo = prompt("Selecciona la operación:\n1. Sumar\n2. Restar\n3. Multiplicar\n4. Dividir\n5. Raíz cuadrada");
      
      // Verificar si la opción es válida (1-5) usando condicionales
      if (tipo === "1" || tipo === "2" || tipo === "3" || tipo === "4" || tipo === "5") {
        break; // Si es válida, salimos del bucle
      } else {
        alert("Opción no válida. Por favor selecciona un número entre 1 y 5.");
      }
    }

    // Si la operación no es raíz cuadrada, pedimos el segundo número
    if (tipo !== "5") {
      num2 = validarInput("Ingresa el segundo número:");
    }

    // Realizamos la operación llamando a la función operacion
    let resultado = operacion(tipo, num1, num2);
    if (resultado !== null) {
      // Si el resultado es válido, lo agregamos al historial
      let operacionTexto;

      if (tipo === "5") {
        // Si tipo es "5", se usa este formato
        operacionTexto = `${operador} ${num1} = ${resultado}`;
      } else {
        // Si tipo no es "5", se usa este formato
        operacionTexto = `${num1} ${operador} ${num2} = ${resultado}`;
      }
      historial.push(operacionTexto);
      let verHistorial;  // Declaramos la variable fuera del bucle

      do {
        verHistorial = prompt("¿Quieres ver el historial? (si/no)").toLowerCase();  // Asignamos el valor a la variable
        
        if (verHistorial === "si") {
          mostrarHistorial();
        } else if (verHistorial === "no") {
          console.log("No mostrar historial");
        } else {
          console.log("Por favor, ingresa 'si' o 'no'.");
        }
      
      } while (verHistorial !== "si" && verHistorial !== "no");  // Continuamos hasta que se ingrese "sí" o "no"
      
      

      let otraOperacion;  // Variable para saber si el usuario quiere hacer otra operación

      do {
        // Preguntar si desea realizar otra operación
        otraOperacion = prompt("¿Quieres realizar otra operación? (si/no)").toLowerCase();
      
        if (otraOperacion === "si") {
          calculadora(); // Llamar de nuevo a la función para continuar con la calculadora
        } else if (otraOperacion === "no") {
          console.log("Gracias por usar la calculadora.");
        } else {
          console.log("Por favor, ingresa 'si' o 'no'.");  // Validación en caso de que el input sea incorrecto
        }
      } while (otraOperacion !== "si" && otraOperacion !== "no");
      
    }
  } catch (error) {
    console.error("No dejo realizar otra operacion:", error.message);
    alert("Ocurrió un error inesperado. Por favor, intenta de nuevo.");
  }
}


// Función que valida que el input sea un número
function validarInput(mensaje) {
  let num;
  while (true) {
    const entrada = prompt(mensaje);
    num = parseFloat(entrada);

    // Verificar si la entrada es un número válido
    if (!isNaN(num)) {
      return num;
    } else {
      alert("Por favor, ingresa un número válido.");
    }
  }
}

// Llamamos a la función principal para iniciar 